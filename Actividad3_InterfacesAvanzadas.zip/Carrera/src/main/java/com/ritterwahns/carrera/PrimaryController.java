package com.ritterwahns.carrera;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;

public class PrimaryController {
    @FXML private Button btnIniciar;
    @FXML private Label lblLiebre;
    @FXML private ProgressBar pbLiebre;
    @FXML private Label lblTortuga;
    @FXML private ProgressBar pbTortuga;

    @FXML
    private void iniciar() {
        btnIniciar.setDisable(true);
        pbLiebre.setProgress(0);
        pbTortuga.setProgress(0);

        Thread liebre = new Thread(() -> {
            Platform.runLater(() -> lblLiebre.setText("La Liebre: ¡Arrancó a toda velocidad!"));
            for (int i = 1; i <= 100; i++) {
                try {
                    if (i == 50) {
                        Platform.runLater(() -> lblLiebre.setText("La Liebre: ¡Se durmió!"));
                        Thread.sleep(6000); 
                        Platform.runLater(() -> lblLiebre.setText("La Liebre: ¡Despertó y corre!"));
                    }
                    Thread.sleep(30);
                } catch (InterruptedException e) {}
                
                double progreso = i / 100.0;
                Platform.runLater(() -> pbLiebre.setProgress(progreso));
            }
            Platform.runLater(() -> lblLiebre.setText("La Liebre: Terminó la carrera"));
        });

        Thread tortuga = new Thread(() -> {
            Platform.runLater(() -> lblTortuga.setText("La Tortuga: ¡Está corriendo!"));
            for (int i = 1; i <= 100; i++) {
                try {
                    Thread.sleep(80);
                } catch (InterruptedException e) {}
                
                double progreso = i / 100.0;
                Platform.runLater(() -> pbTortuga.setProgress(progreso));
            }
            Platform.runLater(() -> {
                lblTortuga.setText("La Tortuga: ¡Llegó a la meta y GANA!");
                btnIniciar.setDisable(false);
            });
        });

        liebre.setDaemon(true);
        tortuga.setDaemon(true);
        liebre.start();
        tortuga.start();
    }
}
