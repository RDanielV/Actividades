module com.ritterwahns.carrera {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.ritterwahns.carrera to javafx.fxml;
    exports com.ritterwahns.carrera;
}
