package com.ritterwahns.conteo;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;

public class PrimaryController {
    @FXML private TextField txtClics;
    @FXML private ProgressBar progressBar;
    @FXML private Button btnEsperar;
    
    private int clics = 0;

    @FXML
    private void contar() {
        clics++;
        txtClics.setText(String.valueOf(clics));
    }

    @FXML
    private void esperar() {
        btnEsperar.setDisable(true);
        progressBar.setProgress(0.0);
        
        Thread hilo = new Thread(() -> {
            for (int i = 1; i <= 100; i++) {
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {}
                
                double progreso = i / 100.0;
                Platform.runLater(() -> progressBar.setProgress(progreso));
            }
            Platform.runLater(() -> btnEsperar.setDisable(false));
        });
        
        hilo.setDaemon(true);
        hilo.start();
    }
}
