module com.ritterwahns.conteo {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.ritterwahns.conteo to javafx.fxml;
    exports com.ritterwahns.conteo;
}
