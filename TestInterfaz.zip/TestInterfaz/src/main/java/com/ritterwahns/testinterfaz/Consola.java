
package com.ritterwahns.testinterfaz;

public class Consola extends Aparato {
   private String nombre;
   private double precio;

    public Consola(String nombre, double precio) {
        this.nombre = nombre;
        this.precio = precio;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Consola{" + "nombre=" + nombre + ", precio=" + precio + '}';
    }
   
   
}
