
package com.ritterwahns.testinterfaz;

public abstract class Aparato implements ControlRemoto {
    protected String encender(){//Repasarlo
        return "¡Aparato encendido!\n";
    }
    
    @Override//Se tiene que agregar para evitar errores con implements ControlRemoto
    public String botonEncenderPresionado(){
        return encender();
    }
}
