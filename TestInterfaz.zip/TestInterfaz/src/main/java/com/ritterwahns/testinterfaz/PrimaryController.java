package com.ritterwahns.testinterfaz;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextArea;

public class PrimaryController implements Initializable {    
    private Persona p;
    private Consola c;
    private Television t;
  
    @FXML TextArea txtPersona;
    @FXML TextArea txtConsola;
    @FXML TextArea txtTelevision;

    @FXML
  
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        p = new Persona("Daniel", 20);
        c = new Consola("Xbox", 13600);
        t = new Television("G45", "LG");
        
        txtPersona.setText( p.toString());
        txtConsola.setText( c.toString());
        txtTelevision.setText( t.toString());

    }
    
    @FXML
    private void accion() {
        txtConsola.appendText(p.precionaBoton(c));
        txtTelevision.appendText(p.precionaBoton(t));
    }
}
