
package com.ritterwahns.testinterfaz;

public class Television extends Aparato {//checar esto como funciona
    private String fabricante;
    private String marca;

    public Television(String fabricante, String marca) {
        this.fabricante = fabricante;
        this.marca = marca;
    }

    public String getFabricante() {
        return fabricante;
    }

    public String getMarca() {
        return marca;
    }

    public void setFabricante(String fabricante) {
        this.fabricante = fabricante;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    @Override
    public String toString() {
        return "Television{" + "fabricante=" + fabricante + ", marca=" + marca + '}';
    }
}
