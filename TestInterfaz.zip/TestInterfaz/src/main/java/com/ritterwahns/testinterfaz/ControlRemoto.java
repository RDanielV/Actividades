
package com.ritterwahns.testinterfaz;

public interface ControlRemoto {
    public String botonEncenderPresionado();
}
