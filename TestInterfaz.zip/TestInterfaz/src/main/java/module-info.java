module com.ritterwahns.testinterfaz {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.ritterwahns.testinterfaz to javafx.fxml;
    exports com.ritterwahns.testinterfaz;
}
