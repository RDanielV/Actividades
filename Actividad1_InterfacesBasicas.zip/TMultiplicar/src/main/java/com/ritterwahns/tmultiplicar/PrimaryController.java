package com.ritterwahns.tmultiplicar;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class PrimaryController {
    @FXML TextField txtNum;
    @FXML TextArea txtTabla;

    @FXML
    private void Calcular() throws IOException {
        String numTot = txtNum.getText();
        int num = Integer.parseInt(numTot);
        
        String resCom="";
        for(int i=1; i<=10; i++){
            resCom = resCom + num +"*"+ i +"= " + (num*i) + "\n";
        }
        txtTabla.setText(resCom);
    }
    
    @FXML
    private void Limpiar() throws IOException {
        txtNum.setText("");
        txtTabla.setText("");
    }
}
