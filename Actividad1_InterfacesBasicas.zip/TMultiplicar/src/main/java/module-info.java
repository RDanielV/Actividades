module com.ritterwahns.tmultiplicar {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.ritterwahns.tmultiplicar to javafx.fxml;
    exports com.ritterwahns.tmultiplicar;
}
