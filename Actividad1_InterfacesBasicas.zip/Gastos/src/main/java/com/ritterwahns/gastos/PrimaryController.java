package com.ritterwahns.gastos;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class PrimaryController {
    @FXML TextField txtAlim;
    @FXML TextField txtRefrigerios;
    @FXML TextField txtTra;
    @FXML TextField txtTelf;
    @FXML TextField txtOtros;
    @FXML TextField txtTotal;
    @FXML TextField txtGastAlto;

    @FXML
    private void Calcular() throws IOException {
        String AlimTotal = txtAlim.getText();
        String RefTotal = txtRefrigerios.getText();
        String TraTotal = txtTra.getText();
        String TelfTotal = txtTelf.getText();
        String OtrosTotal = txtOtros.getText();
        
        int aT = Integer.parseInt(AlimTotal);
        int rT = Integer.parseInt(RefTotal);
        int tT = Integer.parseInt(TraTotal);
        int tefT = Integer.parseInt(TelfTotal);
        int oT = Integer.parseInt(OtrosTotal);
        
        int t = aT + rT + tT + tefT + oT; 
        txtTotal.setText("" + t);
        
        int mayor = aT;
        String nombMayor ="Alimentacion";
        if(rT > mayor){
            mayor = rT;
            nombMayor ="Refrigerios";    
        }
        if (tT > mayor) {
            mayor = tT;
            nombMayor = "Transporte";
        }
        if (tefT > mayor) {
            mayor = tefT;
            nombMayor = "Telefonía";
        }
        if (oT > mayor) {
            mayor = oT;
            nombMayor = "Otros";
        }
        
        txtGastAlto.setText(nombMayor);
    }
    
    @FXML
    private void Limpiar() throws IOException {
        txtAlim.setText("");
        txtRefrigerios.setText("");
        txtTra.setText("");
        txtTelf.setText("");
        txtOtros.setText("");
        txtTotal.setText("");
        txtGastAlto.setText("");
    }
}
