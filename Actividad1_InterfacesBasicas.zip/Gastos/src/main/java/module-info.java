module com.ritterwahns.gastos {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.ritterwahns.gastos to javafx.fxml;
    exports com.ritterwahns.gastos;
}
