package com.ritterwahns.dinero;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class PrimaryController {
    @FXML TextField txtDinero;
    @FXML TextArea txtRes;
    @FXML TextArea txtBilletes;
    
    @FXML
    private void Eliminar() throws IOException {
        txtDinero.setText("");
        txtRes.setText("");
    }
    
    @FXML
    private void Desglosar() throws IOException {
        
        int dTotal = Integer.parseInt(txtDinero.getText());
        
        int b500 = dTotal/500;
        dTotal %= 500;
        
        int b200 = dTotal/200;
        dTotal %= 200;
        
        int b100 = dTotal/100;
        dTotal %= 100;
        
        int b50 = dTotal/50;
        dTotal %= 50;
        
        int b20 = dTotal/20;
        dTotal %= 20;
        
        int m10 = dTotal/10;
        dTotal %= 10;
        
        int m5 = dTotal/5;
        dTotal %= 5;
        
        int m2 = dTotal/2;
        dTotal %= 2;
        
        int m1 = dTotal/1;
        dTotal %= 1;
  
        
        txtBilletes.setText(
            "Billetes de $500\n" +
            "Billetes de $200\n" +
            "Billetes de $100\n" +
            "Billetes de $50\n" +
            "Billetes de $20\n" +
            "Monedas de $10\n" +
            "Monedas de $5\n" +
            "Monedas de $2\n" +
            "Monedas de $1\n");
        
        txtRes.setText(
                b500 +  "\n" +
                b200 +  "\n" + 
                b100 +  "\n" + 
                b50 +  "\n" + 
                b20 +  "\n" + 
                m10 +  "\n" + 
                m5 +  "\n" + 
                m2 +  "\n" + 
                m1 +  "\n");
    }
    
}
