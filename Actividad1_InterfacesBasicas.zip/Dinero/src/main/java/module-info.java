module com.ritterwahns.dinero {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.ritterwahns.dinero to javafx.fxml;
    exports com.ritterwahns.dinero;
}
