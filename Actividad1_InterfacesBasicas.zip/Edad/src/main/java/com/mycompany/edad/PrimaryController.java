package com.mycompany.edad;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

 

public class PrimaryController {
    @FXML TextField txtFecha;
    @FXML Label lblResultado;   
    @FXML
    
    private void accionCalcular() {
        String fechaCompleta = txtFecha.getText();
        String[] pedazos = fechaCompleta.split("/");
        int mesNac = Integer.parseInt(pedazos [1]);
        int anioNac = Integer.parseInt(pedazos [2]);
        int mes = 10 - mesNac;
        int anio = 2026 - anioNac;
        if(mes < 0){
            anio-=1;
            mes+=12;
        }
        lblResultado.setText("Tiene " + anio + " años con "+ mes + " meses");
    }
    
    @FXML
    private void accionLimpiar() {
        lblResultado.setText("");
        txtFecha.setText("");
    }

}


