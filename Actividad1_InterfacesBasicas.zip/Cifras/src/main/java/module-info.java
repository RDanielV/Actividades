module com.ritterwahns.cifras {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.ritterwahns.cifras to javafx.fxml;
    exports com.ritterwahns.cifras;
}
