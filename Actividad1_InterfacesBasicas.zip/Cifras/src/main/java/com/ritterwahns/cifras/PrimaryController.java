package com.ritterwahns.cifras;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class PrimaryController {
    @FXML TextField txtNum;
    @FXML TextField txtCant;
    @FXML TextField txtImp;
    @FXML TextField txtPar;
    @FXML TextField txtSum;
    @FXML TextField txtMay;
    @FXML TextField txtMen;
    @FXML TextArea txtAreaResultados;
    
    @FXML 
    private void Analizar() throws IOException {
        String textoNum = txtNum.getText();
        int numeroCompleto = Integer.parseInt(textoNum);
        int cant = textoNum.length(); 
        int sumaPares = 0;
        int sumaImpares = 0;
        int sumaTotal = 0;
        int mayor = -1;
        int menor = 10;

        for (int i = 0; i < cant; i++) {
            int digito = Character.getNumericValue(textoNum.charAt(i));
            sumaTotal = sumaTotal + digito;
            if (digito % 2 == 0) {
                sumaPares = sumaPares + digito;
            } else {
                sumaImpares = sumaImpares + digito;
            }
            if (digito > mayor) {
                mayor = digito;
            }
            if (digito < menor) {
                menor = digito;
            }
        }
        String textoDivisores = "";
        for (int i = 1; i <= numeroCompleto; i++) {
            if (numeroCompleto % i == 0) {
                textoDivisores = textoDivisores + i + "\n";
            }
        }

        txtCant.setText("" + cant);
        txtPar.setText("" + sumaPares);
        txtImp.setText("" + sumaImpares);
        txtSum.setText("" + sumaTotal);
        txtMay.setText("" + mayor);
        txtMen.setText("" + menor);
        txtAreaResultados.setText(textoDivisores);
    }
    
    @FXML 
    private void Limpiar() throws IOException {
        txtNum.setText("");
        txtCant.setText("");
        txtImp.setText("");
        txtPar.setText("");
        txtSum.setText("");
        txtMay.setText("");
        txtMen.setText("");
        txtAreaResultados.setText("");
    }
}
