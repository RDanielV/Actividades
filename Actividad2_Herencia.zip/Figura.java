public class Main {
    public static void main(String[] args) {
        Figura2D f = new TrianguloRect(3, 4);
        System.out.println(f.imprimeFigura());
        
        f = new Circulo(3);
        System.out.println(f.imprimeFigura());
    }
}

interface FiguraPlana {
    double calcularArea();
    double calcularPerimetro();
}

abstract class Figura2D implements FiguraPlana {
    protected String imprimeFigura() {
        return "Se imprime una FiguraPlana...\n";
    }
}

// CORRECCIÓN: Agregamos abstract
abstract class FiguraRecta extends Figura2D {
    protected int ancho;
    protected int alto;
}

// CORRECCIÓN: Agregamos abstract
abstract class FiguraCircular extends Figura2D {
    protected int radio;
}

class TrianguloRect extends FiguraRecta {
    public TrianguloRect(int alto, int ancho) {
        this.alto = alto;
        this.ancho = ancho;
    }

    @Override
    public double calcularArea() {
        return (double) (ancho * alto) / 2.0;
    }

    @Override
    public double calcularPerimetro() {
        double hipotenusa = Math.sqrt(Math.pow(ancho, 2) + Math.pow(alto, 2));
        return ancho + alto + hipotenusa;
    }

    @Override
    public String imprimeFigura() {
        return super.imprimeFigura() + 
               "Se imprime un Triangulo con alto: " + alto + ", ancho: " + ancho + 
               ", area: " + String.format("%.2f", calcularArea()) + 
               ", perimetro: " + String.format("%.2f", calcularPerimetro()) + "\n";
    }
}

class Circulo extends FiguraCircular {
    public Circulo(int radio) {
        this.radio = radio;
    }

    @Override
    public double calcularArea() {
        return Math.PI * Math.pow(radio, 2);
    }

    @Override
    public double calcularPerimetro() {
        return 2 * Math.PI * radio;
    }

    @Override
    public String imprimeFigura() {
        return super.imprimeFigura() + 
               "Se imprime un Circulo con radio: " + radio + 
               ", area: " + String.format("%.2f", calcularArea()) + 
               ", perimetro: " + String.format("%.2f", calcularPerimetro()) + "\n";
    }
}